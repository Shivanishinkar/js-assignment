Marks =Number (prompt("Enter your marks"))
console.log(Marks)
if(Marks>90 && Marks <=100)
{
  console.log(`Your Marks ${Marks} And your Grade is A1`);
}
else if(Marks>80 &&Marks<=90)
{
  console.log(`Your Marks ${Marks}And Your Grade is B`);
}
else if(Marks>70 &&Marks<=80)
{
  console.log(`Your Marks ${Marks}And Your Grade is c`);
}
else if(Marks>60 &&Marks<=70)
{
  console.log(`Your Marks ${Marks}And Your Grade is D`);
}
else if(Marks>50 &&Marks<=60)
{
  console.log(`Your Marks ${Marks}And Your Grade is E`);
}
else{
  console .log(`You are Fail`);
}